from .core import Yvel, weightedLinregress, ortDistanceRegress

__all__ = ["Yvel", "weightedLinregress","ortDistanceRegress"]